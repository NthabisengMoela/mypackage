#   mypackage

# How to install 
...